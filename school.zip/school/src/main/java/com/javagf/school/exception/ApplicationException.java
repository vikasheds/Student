package com.javagf.school.exception;

public class ApplicationException {

}
