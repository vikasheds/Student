package com.javagf.school.dao;

public interface StudentDao {

}
