package com.javagf.school.service;

public interface StudentService {

}
