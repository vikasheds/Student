package com.javagf.school.api;

public interface StudentApi {

}
